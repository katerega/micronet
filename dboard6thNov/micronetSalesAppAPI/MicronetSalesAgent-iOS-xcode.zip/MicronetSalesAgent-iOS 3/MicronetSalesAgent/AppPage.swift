import SwiftUI

/// The seven pages from MainActivity.setupNavigation()
enum AppPage: CaseIterable, Identifiable {
    case dashboard, visits, customers, sales, invoices, followups, products

    var id: Self { self }

    var title: String {
        switch self {
        case .dashboard: return "Dashboard"
        case .visits:    return "Sales Visits"
        case .customers: return "Customers"
        case .sales:     return "Sales & Delivery"
        case .invoices:  return "Invoices"
        case .followups: return "Follow-ups"
        case .products:  return "Products"
        }
    }

    var subtitle: String {
        switch self {
        case .dashboard: return "Your sales activity for today."
        case .visits:    return "Record customer and prospect visits."
        case .customers: return "Manage your customer relationships."
        case .sales:     return "Record products sold and delivered."
        case .invoices:  return "Track payments and outstanding balances."
        case .followups: return "Customers requiring your attention."
        case .products:  return "Track products and quantities sold."
        }
    }

    /// Short label for the bottom bar
    var navLabel: String {
        switch self {
        case .dashboard: return "Home"
        case .visits:    return "Visits"
        case .customers: return "Customers"
        case .sales:     return "Sales"
        case .invoices:  return "Invoices"
        case .followups: return "Alerts"
        case .products:  return "Products"
        }
    }

    /// SF Symbols replace the Unicode glyphs used on Android
    var symbol: String {
        switch self {
        case .dashboard: return "house.fill"
        case .visits:    return "mappin.and.ellipse"
        case .customers: return "person.2.fill"
        case .sales:     return "cart.fill"
        case .invoices:  return "doc.text.fill"
        case .followups: return "exclamationmark.triangle.fill"
        case .products:  return "shippingbox.fill"
        }
    }
}
