import SwiftUI

// MARK: - Models

struct Customer: Identifiable {
    let id = UUID()
    var name, phone, location: String
    var followUp = false
}

struct Visit: Identifiable {
    let id = UUID()
    var customer, purpose, time: String
    var done = false
}

struct Product: Identifiable {
    let id = UUID()
    var name: String
    var price: Int
    var stock: Int
    var sold = 0
}

struct Sale: Identifiable {
    let id = UUID()
    var customer, product: String
    var qty, price: Int
    var delivered = false
    var total: Int { qty * price }
}

struct Invoice: Identifiable {
    let id = UUID()
    var no, customer: String
    var amount: Int
    var due: Date
    var paid = false

    var daysLeft: Int {
        let cal = Calendar.current
        return cal.dateComponents([.day], from: cal.startOfDay(for: Date()),
                                  to: cal.startOfDay(for: due)).day ?? 0
    }
    var overdue: Bool { !paid && daysLeft < 0 }
    var dueLabel: String {
        if paid { return "Paid" }
        if daysLeft < 0 { return "Overdue by \(-daysLeft) day\(daysLeft == -1 ? "" : "s")" }
        return daysLeft == 0 ? "Due today" : "Due in \(daysLeft) days"
    }
}

struct AlertItem: Identifiable {
    let id: String
    let title, sub, tag: String
    let phone: String?
    let resolve: () -> Void
}

/// 1250000 -> "UGX 1,250,000"
func ugx(_ n: Int) -> String {
    let f = NumberFormatter()
    f.numberStyle = .decimal
    f.groupingSeparator = ","
    return "UGX " + (f.string(from: NSNumber(value: n)) ?? "\(n)")
}

func dial(_ phone: String) {
    let digits = phone.filter { !$0.isWhitespace }
    if let url = URL(string: "tel://\(digits)") { UIApplication.shared.open(url) }
}

// MARK: - Auth

enum AuthError: LocalizedError {
    case invalid
    var errorDescription: String? { "Incorrect username or password." }
}

/// Demo authentication - replace the body of `signIn` with a call to your backend
/// and keep the token in the Keychain.
@MainActor
final class AuthStore: ObservableObject {
    static let demoUsername = "agent"
    static let demoPassword = "micronet123"

    @Published var agentName: String? = nil

    func signIn(username: String, password: String) async throws {
        try await Task.sleep(nanoseconds: 900_000_000)
        guard username.trimmingCharacters(in: .whitespaces).lowercased() == Self.demoUsername,
              password == Self.demoPassword else { throw AuthError.invalid }
        agentName = "Michael"
    }

    func signOut() { agentName = nil }
}

// MARK: - Data store (in-memory demo data)

final class Store: ObservableObject {
    private static func day(_ n: Int) -> Date {
        Calendar.current.date(byAdding: .day, value: n, to: Date()) ?? Date()
    }

    @Published var customers = [
        Customer(name: "ABC Supermarket", phone: "0772 123 456", location: "Kampala Central", followUp: true),
        Customer(name: "Fresh Mart", phone: "0701 555 210", location: "Ntinda"),
        Customer(name: "City Traders", phone: "0752 908 114", location: "Nakawa"),
        Customer(name: "Kato Wholesalers", phone: "0782 330 771", location: "Owino Market", followUp: true),
    ]
    @Published var visits = [
        Visit(customer: "ABC Supermarket", purpose: "Payment collection", time: "9:00 AM", done: true),
        Visit(customer: "Fresh Mart", purpose: "New order", time: "11:30 AM", done: true),
        Visit(customer: "City Traders", purpose: "Product demo", time: "2:00 PM"),
        Visit(customer: "Kato Wholesalers", purpose: "Payment follow-up", time: "4:00 PM"),
    ]
    @Published var products = [
        Product(name: "Sugar 1kg", price: 4500, stock: 120, sold: 64),
        Product(name: "Cooking Oil 3L", price: 18000, stock: 8, sold: 41),
        Product(name: "Rice 5kg", price: 22000, stock: 45, sold: 27),
        Product(name: "Bar Soap", price: 2500, stock: 6, sold: 90),
    ]
    @Published var sales = [
        Sale(customer: "Fresh Mart", product: "Sugar 1kg", qty: 40, price: 4500, delivered: true),
        Sale(customer: "ABC Supermarket", product: "Rice 5kg", qty: 20, price: 22000),
        Sale(customer: "City Traders", product: "Cooking Oil 3L", qty: 12, price: 18000),
    ]
    @Published var invoices = [
        Invoice(no: "INV-0245", customer: "ABC Supermarket", amount: 1_000_000, due: Store.day(0)),
        Invoice(no: "INV-0238", customer: "Kato Wholesalers", amount: 950_000, due: Store.day(-5)),
        Invoice(no: "INV-0250", customer: "Fresh Mart", amount: 600_000, due: Store.day(7)),
        Invoice(no: "INV-0231", customer: "City Traders", amount: 400_000, due: Store.day(-12), paid: true),
    ]

    private func mutate<T: Identifiable>(_ list: inout [T], _ item: T, _ change: (inout T) -> Void) {
        if let i = list.firstIndex(where: { $0.id == item.id }) { change(&list[i]) }
    }

    func addCustomer(_ c: Customer) { customers.insert(c, at: 0) }
    func addVisit(_ v: Visit) { visits.insert(v, at: 0) }
    func addProduct(_ p: Product) { products.insert(p, at: 0) }
    func completeVisit(_ v: Visit) { mutate(&visits, v) { $0.done = true } }
    func deliver(_ s: Sale) { mutate(&sales, s) { $0.delivered = true } }
    func markPaid(_ i: Invoice) { mutate(&invoices, i) { $0.paid = true } }
    func clearFollowUp(_ c: Customer) { mutate(&customers, c) { $0.followUp = false } }

    func addInvoice(customer: String, amount: Int, days: Int) {
        let no = "INV-" + String(format: "%04d", 300 + invoices.count)
        invoices.insert(Invoice(no: no, customer: customer, amount: amount, due: Store.day(days)), at: 0)
    }

    func addSale(_ s: Sale) {
        sales.insert(s, at: 0)
        if let i = products.firstIndex(where: { $0.name.lowercased() == s.product.lowercased() }) {
            products[i].stock = max(0, products[i].stock - s.qty)
            products[i].sold += s.qty
        }
    }

    private func phone(of name: String) -> String? {
        customers.first { $0.name == name }?.phone
    }

    /// Unpaid invoices that are due/overdue + customers flagged for follow-up.
    var alerts: [AlertItem] {
        let invoiceAlerts = invoices.filter { !$0.paid && $0.daysLeft <= 0 }.map { i in
            AlertItem(id: i.id.uuidString, title: i.customer,
                      sub: "\(i.no) · \(ugx(i.amount)) · \(i.dueLabel)",
                      tag: i.overdue ? "Overdue" : "Due today",
                      phone: phone(of: i.customer)) { self.markPaid(i) }
        }
        let customerAlerts = customers.filter { $0.followUp }.map { c in
            AlertItem(id: c.id.uuidString, title: c.name, sub: "Customer follow-up required",
                      tag: "Follow-up", phone: c.phone) { self.clearFollowUp(c) }
        }
        return invoiceAlerts + customerAlerts
    }
}
