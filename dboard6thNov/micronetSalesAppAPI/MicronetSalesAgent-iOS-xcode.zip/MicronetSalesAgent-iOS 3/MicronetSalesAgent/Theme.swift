import SwiftUI

extension Color {
    /// Create a colour from a hex value, e.g. Color(hex: 0x2563EB)
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }
}

/// Colours taken from activity_main.xml
enum Theme {
    static let background    = Color(hex: 0xF5F7FB)
    static let card          = Color.white
    static let textPrimary   = Color(hex: 0x172033)
    static let textSecondary = Color(hex: 0x667085)
    static let blue          = Color(hex: 0x2563EB)
    static let green         = Color(hex: 0x16A34A)
    static let red           = Color(hex: 0xDC2626)
    static let blueSoft      = Color(hex: 0xEFF6FF)
    static let greenSoft     = Color(hex: 0xECFDF3)
    static let redSoft       = Color(hex: 0xFEF2F2)
    static let navy          = Color(hex: 0x101828)
}
