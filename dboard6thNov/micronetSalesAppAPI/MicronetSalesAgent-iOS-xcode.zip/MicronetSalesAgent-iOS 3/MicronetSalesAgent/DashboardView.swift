import SwiftUI

struct DashboardView: View {
    @EnvironmentObject var store: Store
    @EnvironmentObject var auth: AuthStore
    var onNavigate: (AppPage) -> Void = { _ in }

    private var greeting: String {
        let h = Calendar.current.component(.hour, from: Date())
        return h < 12 ? "Good morning" : (h < 17 ? "Good afternoon" : "Good evening")
    }
    private var salesTotal: Int { store.sales.reduce(0) { $0 + $1.total } }
    private var collected: Int { store.invoices.filter { $0.paid }.reduce(0) { $0 + $1.amount } }
    private var outstanding: Int { store.invoices.filter { !$0.paid }.reduce(0) { $0 + $1.amount } }
    private var visitsDone: Int { store.visits.filter { $0.done }.count }

    private func short(_ n: Int) -> String {
        n >= 1_000_000 ? String(format: "UGX %.2fM", Double(n) / 1_000_000) : ugx(n)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {

                // WELCOME
                VStack(alignment: .leading, spacing: 5) {
                    Text("\(greeting), \(auth.agentName ?? "") .")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(Theme.textPrimary)
                    Text("Track your field sales, deliveries and collections.")
                        .font(.system(size: 13))
                        .foregroundColor(Theme.textSecondary)
                }
                .padding(18)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Theme.card)
                .cornerRadius(12)

                // STAT CARDS
                HStack(spacing: 14) {
                    StatCard(title: "SALES", value: short(salesTotal),
                             caption: "\(store.sales.count) orders", color: Theme.textPrimary, captionColor: Theme.green)
                    StatCard(title: "COLLECTIONS", value: short(collected),
                             caption: "\(store.invoices.filter { $0.paid }.count) invoices paid", color: Theme.textPrimary, captionColor: Theme.green)
                }
                .padding(.top, 16)

                HStack(spacing: 14) {
                    StatCard(title: "OUTSTANDING", value: short(outstanding),
                             caption: "Follow-up required", color: Theme.red, captionColor: Theme.red)
                    StatCard(title: "VISITS", value: "\(store.visits.count)",
                             caption: "\(visitsDone) completed", color: Theme.textPrimary,
                             captionColor: Theme.green, valueSize: 25)
                }
                .padding(.top, 12)

                // START VISIT
                Button { onNavigate(.visits) } label: {
                    Text("+ START SALES VISIT")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, minHeight: 55)
                        .background(Theme.blue)
                        .cornerRadius(10)
                }
                .buttonStyle(.plain)
                .padding(.top, 18)

                // QUICK ACTIONS
                SectionTitle("QUICK ACTIONS", top: 24)

                HStack(spacing: 8) {
                    QuickActionButton(title: "+ SALE", color: Theme.blue, background: Theme.blueSoft) { onNavigate(.sales) }
                    QuickActionButton(title: "PAYMENT", color: Theme.green, background: Theme.greenSoft) { onNavigate(.invoices) }
                    QuickActionButton(title: "FOLLOW-UP", color: Theme.red, background: Theme.redSoft) { onNavigate(.followups) }
                }

                // PAYMENT FOLLOW-UPS
                SectionTitle("PAYMENT FOLLOW-UPS", top: 25)

                let items = Array(store.alerts.prefix(3))
                if items.isEmpty {
                    Text("You're all caught up 🎉")
                        .font(.system(size: 13))
                        .foregroundColor(Theme.textSecondary)
                }
                VStack(spacing: 10) {
                    ForEach(items) { a in
                        VStack(alignment: .leading, spacing: 0) {
                            Text(a.title)
                                .font(.system(size: 15, weight: .bold))
                                .foregroundColor(Theme.textPrimary)
                            Text(a.sub)
                                .font(.system(size: 12))
                                .foregroundColor(Theme.red)
                                .padding(.top, 4)
                            if let phone = a.phone {
                                Button { dial(phone) } label: {
                                    Text("CALL CUSTOMER")
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundColor(.white)
                                        .padding(.horizontal, 18)
                                        .frame(height: 45)
                                        .background(Theme.blue)
                                        .cornerRadius(8)
                                }
                                .buttonStyle(.plain)
                                .padding(.top, 10)
                            }
                        }
                        .padding(15)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Theme.card)
                        .cornerRadius(12)
                    }
                }
            }
            .padding(18)
        }
    }
}

// MARK: - Reusable pieces

struct StatCard: View {
    let title: String
    let value: String
    let caption: String
    let color: Color
    let captionColor: Color
    var valueSize: CGFloat = 21

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(title)
                .font(.system(size: 11))
                .foregroundColor(Theme.textSecondary)
            Text(value)
                .font(.system(size: valueSize, weight: .bold))
                .foregroundColor(color)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
                .padding(.top, 10)
            Text(caption)
                .font(.system(size: 11))
                .foregroundColor(captionColor)
        }
        .padding(15)
        .frame(maxWidth: .infinity, minHeight: 110, maxHeight: 110, alignment: .topLeading)
        .background(Theme.card)
        .cornerRadius(12)
    }
}

struct SectionTitle: View {
    let text: String
    let top: CGFloat

    init(_ text: String, top: CGFloat) {
        self.text = text
        self.top = top
    }

    var body: some View {
        Text(text)
            .font(.system(size: 13, weight: .bold))
            .foregroundColor(Theme.textSecondary)
            .padding(.top, top)
            .padding(.bottom, 10)
    }
}

struct QuickActionButton: View {
    let title: String
    let color: Color
    let background: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(color)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
                .frame(maxWidth: .infinity, minHeight: 52)
                .background(background)
                .cornerRadius(10)
        }
        .buttonStyle(.plain)
    }
}

struct DashboardView_Previews: PreviewProvider {
    static var previews: some View {
        DashboardView()
            .environmentObject(Store())
            .environmentObject(AuthStore())
            .background(Theme.background)
    }
}
