import SwiftUI

// MARK: - Visits

struct VisitsPage: View {
    @EnvironmentObject var store: Store
    @State private var adding = false

    var body: some View {
        SearchableList(
            items: store.visits,
            text: { "\($0.customer) \($0.purpose)" },
            filters: ["All", "Pending", "Completed"],
            match: { v, f in f == "Completed" ? v.done : !v.done },
            addLabel: "Visit", onAdd: { adding = true }
        ) { v in
            InfoCard(title: v.customer, sub: "\(v.purpose) · \(v.time)",
                     pill: v.done ? .ok("Completed") : .info("Pending"),
                     actions: v.done ? [] : [("MARK COMPLETE", { store.completeVisit(v) })])
        }
        .sheet(isPresented: $adding) {
            FormSheet(title: "New sales visit", labels: ["Customer", "Purpose", "Time (e.g. 2:00 PM)"]) { v in
                store.addVisit(Visit(customer: v[0], purpose: v[1], time: v[2]))
            }
        }
    }
}

// MARK: - Customers

struct CustomersPage: View {
    @EnvironmentObject var store: Store
    @State private var adding = false

    var body: some View {
        SearchableList(
            items: store.customers,
            text: { "\($0.name) \($0.phone) \($0.location)" },
            filters: ["All", "Follow-up"],
            match: { c, _ in c.followUp },
            addLabel: "Customer", onAdd: { adding = true }
        ) { c in
            InfoCard(title: c.name, sub: "\(c.phone) · \(c.location)",
                     pill: c.followUp ? .bad("Follow-up") : nil,
                     actions: [("CALL", { dial(c.phone) })])
        }
        .sheet(isPresented: $adding) {
            FormSheet(title: "New customer", labels: ["Name", "Phone", "Location"]) { v in
                store.addCustomer(Customer(name: v[0], phone: v[1], location: v[2]))
            }
        }
    }
}

// MARK: - Sales

struct SalesPage: View {
    @EnvironmentObject var store: Store
    @State private var adding = false

    var body: some View {
        SearchableList(
            items: store.sales,
            text: { "\($0.customer) \($0.product)" },
            filters: ["All", "Delivered", "Pending"],
            match: { s, f in f == "Delivered" ? s.delivered : !s.delivered },
            addLabel: "Sale", onAdd: { adding = true }
        ) { s in
            InfoCard(title: s.customer, sub: "\(s.qty) × \(s.product)\n\(ugx(s.total))",
                     pill: s.delivered ? .ok("Delivered") : .info("Pending"),
                     actions: s.delivered ? [] : [("MARK DELIVERED", { store.deliver(s) })])
        }
        .sheet(isPresented: $adding) {
            FormSheet(title: "Record sale",
                      labels: ["Customer", "Product", "Quantity", "Unit price (UGX)"],
                      numeric: [2, 3]) { v in
                store.addSale(Sale(customer: v[0], product: v[1],
                                   qty: Int(v[2]) ?? 0, price: Int(v[3]) ?? 0))
            }
        }
    }
}

// MARK: - Invoices

struct InvoicesPage: View {
    @EnvironmentObject var store: Store
    @State private var adding = false

    var body: some View {
        SearchableList(
            items: store.invoices,
            text: { "\($0.no) \($0.customer)" },
            filters: ["All", "Unpaid", "Overdue", "Paid"],
            match: { i, f in
                switch f {
                case "Unpaid": return !i.paid
                case "Overdue": return i.overdue
                default: return i.paid
                }
            },
            addLabel: "Invoice", onAdd: { adding = true }
        ) { i in
            InfoCard(title: "\(i.no) · \(i.customer)", sub: "\(ugx(i.amount))\n\(i.dueLabel)",
                     pill: i.paid ? .ok("Paid") : (i.overdue ? .bad("Overdue") : .info("Unpaid")),
                     actions: i.paid ? [] : [("MARK PAID", { store.markPaid(i) })])
        }
        .sheet(isPresented: $adding) {
            FormSheet(title: "New invoice",
                      labels: ["Customer", "Amount (UGX)", "Due in (days)"],
                      numeric: [1, 2]) { v in
                store.addInvoice(customer: v[0], amount: Int(v[1]) ?? 0, days: Int(v[2]) ?? 0)
            }
        }
    }
}

// MARK: - Alerts

struct AlertsPage: View {
    @EnvironmentObject var store: Store

    var body: some View {
        SearchableList(
            items: store.alerts,
            text: { "\($0.title) \($0.sub)" },
            empty: "No alerts — you're all caught up 🎉"
        ) { a in
            InfoCard(title: a.title, sub: a.sub, pill: .bad(a.tag), actions: actions(for: a))
        }
    }

    private func actions(for a: AlertItem) -> [(String, () -> Void)] {
        var list: [(String, () -> Void)] = []
        if let phone = a.phone { list.append(("CALL", { dial(phone) })) }
        list.append(("RESOLVE", a.resolve))
        return list
    }
}

// MARK: - Products

struct ProductsPage: View {
    @EnvironmentObject var store: Store
    @State private var adding = false

    var body: some View {
        SearchableList(
            items: store.products,
            text: { $0.name },
            filters: ["All", "Low stock"],
            match: { p, _ in p.stock <= 10 },
            addLabel: "Product", onAdd: { adding = true }
        ) { p in
            InfoCard(title: p.name, sub: "\(ugx(p.price)) · \(p.sold) sold",
                     pill: p.stock <= 10 ? .bad("\(p.stock) left") : .ok("\(p.stock) in stock"))
        }
        .sheet(isPresented: $adding) {
            FormSheet(title: "New product",
                      labels: ["Name", "Price (UGX)", "Opening stock"],
                      numeric: [1, 2]) { v in
                store.addProduct(Product(name: v[0], price: Int(v[1]) ?? 0, stock: Int(v[2]) ?? 0))
            }
        }
    }
}
