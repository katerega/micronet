import SwiftUI

struct LoginView: View {
    @EnvironmentObject var auth: AuthStore

    @State private var username = ""
    @State private var password = ""
    @State private var showPassword = false
    @State private var loading = false
    @State private var error: String?
    @FocusState private var focus: Field?

    private enum Field { case user, pass }

    private var canSubmit: Bool {
        !username.trimmingCharacters(in: .whitespaces).isEmpty && !password.isEmpty && !loading
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 28) {
                brand
                formCard
                Text("Field sales, deliveries and collections")
                    .font(.system(size: 11))
                    .foregroundColor(Theme.textSecondary)
            }
            .padding(22)
            .frame(maxWidth: 420)
            .frame(maxWidth: .infinity)
            .padding(.top, 40)
        }
        .background(Theme.background.ignoresSafeArea())
    }

    private var brand: some View {
        VStack(spacing: 14) {
            Image(systemName: "network")
                .font(.system(size: 30, weight: .semibold))
                .foregroundColor(.white)
                .frame(width: 68, height: 68)
                .background(Theme.navy)
                .cornerRadius(18)
            Text("Micronet Sales Agent")
                .font(.system(size: 24, weight: .heavy))
                .foregroundColor(Theme.textPrimary)
            Text("Sign in to continue")
                .font(.system(size: 14))
                .foregroundColor(Theme.textSecondary)
        }
    }

    private var formCard: some View {
        VStack(spacing: 14) {
            fieldBox(icon: "person") {
                TextField("Username", text: $username)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .textContentType(.username)
                    .focused($focus, equals: .user)
                    .submitLabel(.next)
                    .onSubmit { focus = .pass }
            }

            fieldBox(icon: "lock") {
                Group {
                    if showPassword {
                        TextField("Password", text: $password)
                    } else {
                        SecureField("Password", text: $password)
                    }
                }
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textContentType(.password)
                .focused($focus, equals: .pass)
                .submitLabel(.go)
                .onSubmit { if canSubmit { Task { await submit() } } }

                Button { showPassword.toggle() } label: {
                    Image(systemName: showPassword ? "eye.slash" : "eye")
                        .foregroundColor(Theme.textSecondary)
                }
            }

            if let error = error {
                HStack(spacing: 8) {
                    Image(systemName: "exclamationmark.circle")
                    Text(error).font(.system(size: 13))
                    Spacer()
                }
                .foregroundColor(Theme.red)
                .padding(12)
                .background(Theme.redSoft)
                .cornerRadius(10)
            }

            Button { Task { await submit() } } label: {
                Group {
                    if loading { ProgressView().tint(.white) }
                    else { Text("SIGN IN").font(.system(size: 15, weight: .bold)) }
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity, minHeight: 52)
                .background(canSubmit || loading ? Theme.blue : Theme.blue.opacity(0.45))
                .cornerRadius(10)
            }
            .disabled(!canSubmit)

            #if DEBUG
            Text("Debug demo login: \(AuthStore.demoUsername) / \(AuthStore.demoPassword)")
                .font(.system(size: 11))
                .foregroundColor(Theme.textSecondary)
            #endif
        }
        .padding(20)
        .background(Theme.card)
        .cornerRadius(16)
        .shadow(color: Color.black.opacity(0.08), radius: 16, y: 4)
    }

    private func fieldBox<Content: View>(icon: String, @ViewBuilder content: () -> Content) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon).foregroundColor(Theme.textSecondary).frame(width: 20)
            content()
        }
        .padding(14)
        .background(Color.white)
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color(hex: 0xD0D5DD)))
    }

    private func submit() async {
        focus = nil
        error = nil
        loading = true
        do {
            try await auth.signIn(username: username, password: password)
        } catch {
            self.error = error.localizedDescription
        }
        loading = false
    }
}
