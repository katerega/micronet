import SwiftUI

@main
struct MicronetSalesAgentApp: App {
    @StateObject private var auth = AuthStore()
    @StateObject private var store = Store()

    var body: some Scene {
        WindowGroup {
            Group {
                if auth.agentName != nil {
                    ContentView()
                } else {
                    LoginView()
                }
            }
            .animation(.easeInOut(duration: 0.25), value: auth.agentName)
            .environmentObject(auth)
            .environmentObject(store)
            // The Android layout uses fixed light colours, so keep the same look.
            .preferredColorScheme(.light)
        }
    }
}
