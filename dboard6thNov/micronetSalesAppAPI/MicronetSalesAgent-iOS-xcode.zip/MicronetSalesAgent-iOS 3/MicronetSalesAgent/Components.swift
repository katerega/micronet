import SwiftUI

struct StatusPill: View {
    let text: String
    var color: Color = Theme.blue
    var bg: Color = Theme.blueSoft

    var body: some View {
        Text(text)
            .font(.system(size: 11, weight: .bold))
            .foregroundColor(color)
            .padding(.horizontal, 10).padding(.vertical, 4)
            .background(bg)
            .clipShape(Capsule())
    }

    static func ok(_ t: String) -> StatusPill { StatusPill(text: t, color: Theme.green, bg: Theme.greenSoft) }
    static func bad(_ t: String) -> StatusPill { StatusPill(text: t, color: Theme.red, bg: Theme.redSoft) }
    static func info(_ t: String) -> StatusPill { StatusPill(text: t) }
}

/// Card row used by every list page.
struct InfoCard: View {
    let title: String
    let sub: String
    var pill: StatusPill? = nil
    var actions: [(String, () -> Void)] = []

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.system(size: 15, weight: .bold))
                        .foregroundColor(Theme.textPrimary)
                    Text(sub)
                        .font(.system(size: 12))
                        .foregroundColor(Theme.textSecondary)
                }
                Spacer(minLength: 8)
                if let pill = pill { pill }
            }
            if !actions.isEmpty {
                HStack(spacing: 18) {
                    ForEach(actions.indices, id: \.self) { i in
                        Button(actions[i].0, action: actions[i].1)
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(Theme.blue)
                    }
                }
            }
        }
        .padding(15)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.card)
        .cornerRadius(12)
    }
}

/// Search box + filter chips + list + floating add button.
struct SearchableList<T: Identifiable, Row: View>: View {
    let items: [T]
    let text: (T) -> String
    var filters: [String]
    var match: ((T, String) -> Bool)?
    var addLabel: String?
    var onAdd: (() -> Void)?
    var empty: String
    let row: (T) -> Row

    @State private var query = ""
    @State private var filter = "All"

    init(items: [T], text: @escaping (T) -> String, filters: [String] = ["All"],
         match: ((T, String) -> Bool)? = nil, addLabel: String? = nil,
         onAdd: (() -> Void)? = nil, empty: String = "Nothing here yet",
         @ViewBuilder row: @escaping (T) -> Row) {
        self.items = items; self.text = text; self.filters = filters; self.match = match
        self.addLabel = addLabel; self.onAdd = onAdd; self.empty = empty; self.row = row
    }

    private var shown: [T] {
        items
            .filter { filter == "All" || (match?($0, filter) ?? true) }
            .filter { query.isEmpty || text($0).localizedCaseInsensitiveContains(query) }
    }

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            VStack(spacing: 0) {
                HStack {
                    Image(systemName: "magnifyingglass").foregroundColor(Theme.textSecondary)
                    TextField("Search", text: $query)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                .padding(12)
                .background(Color.white)
                .cornerRadius(10)
                .padding(.horizontal, 18).padding(.top, 14).padding(.bottom, 8)

                if filters.count > 1 { chips }

                ScrollView {
                    LazyVStack(spacing: 10) {
                        ForEach(shown) { row($0) }
                    }
                    .padding(.horizontal, 18).padding(.top, 8).padding(.bottom, 90)

                    if shown.isEmpty {
                        Text(empty).font(.system(size: 14)).foregroundColor(Theme.textSecondary)
                            .padding(.top, 40)
                    }
                }
            }

            if let onAdd = onAdd {
                Button(action: onAdd) {
                    Label((addLabel ?? "Add").uppercased(), systemImage: "plus")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 18).padding(.vertical, 14)
                        .background(Theme.blue)
                        .clipShape(Capsule())
                        .shadow(color: Color.black.opacity(0.2), radius: 6, y: 3)
                }
                .padding(18)
            }
        }
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(filters, id: \.self) { f in
                    Button { filter = f } label: {
                        Text(f)
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(filter == f ? Theme.blue : Theme.textSecondary)
                            .padding(.horizontal, 14).padding(.vertical, 8)
                            .background(filter == f ? Theme.blueSoft : Color.white)
                            .clipShape(Capsule())
                    }
                }
            }
            .padding(.horizontal, 18)
        }
    }
}

/// Sheet with one text field per label.
struct FormSheet: View {
    let title: String
    let labels: [String]
    var numeric: Set<Int> = []
    let onSave: ([String]) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var values: [String]

    init(title: String, labels: [String], numeric: Set<Int> = [], onSave: @escaping ([String]) -> Void) {
        self.title = title; self.labels = labels; self.numeric = numeric; self.onSave = onSave
        _values = State(initialValue: Array(repeating: "", count: labels.count))
    }

    private var valid: Bool {
        values.indices.allSatisfy { i in
            let t = values[i].trimmingCharacters(in: .whitespaces)
            return !t.isEmpty && (!numeric.contains(i) || Int(t) != nil)
        }
    }

    var body: some View {
        NavigationView {
            Form {
                ForEach(labels.indices, id: \.self) { i in
                    TextField(labels[i], text: $values[i])
                        .keyboardType(numeric.contains(i) ? .numberPad : .default)
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        onSave(values.map { $0.trimmingCharacters(in: .whitespaces) })
                        dismiss()
                    }
                    .disabled(!valid)
                }
            }
        }
    }
}
