import SwiftUI

struct ContentView: View {
    @EnvironmentObject var auth: AuthStore
    @State private var page: AppPage = .dashboard

    var body: some View {
        VStack(spacing: 0) {
            HeaderBar(page: page, onSignOut: { auth.signOut() })

            Group {
                switch page {
                case .dashboard: DashboardView(onNavigate: { page = $0 })
                case .visits:    VisitsPage()
                case .customers: CustomersPage()
                case .sales:     SalesPage()
                case .invoices:  InvoicesPage()
                case .followups: AlertsPage()
                case .products:  ProductsPage()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            BottomBar(selection: $page)
        }
        .background(Theme.background.ignoresSafeArea())
    }
}

// MARK: - Header (title, subtitle, punch button)

struct HeaderBar: View {
    let page: AppPage
    let onSignOut: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text(page.title)
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(Theme.textPrimary)
                Text(page.subtitle)
                    .font(.system(size: 12))
                    .foregroundColor(Theme.textSecondary)
            }

            Spacer()

            Button {
                // TODO: punch in / out (not implemented in the Android source either)
            } label: {
                Text("PUNCH IN")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(Theme.blue)
                    .cornerRadius(8)
            }
            .buttonStyle(.plain)

            Menu {
                Button(role: .destructive, action: onSignOut) {
                    Label("Sign out", systemImage: "rectangle.portrait.and.arrow.right")
                }
            } label: {
                Image(systemName: "ellipsis.circle")
                    .font(.system(size: 22))
                    .foregroundColor(Theme.textSecondary)
            }
            .padding(.leading, 6)
        }
        .padding(.horizontal, 18)
        .frame(minHeight: 80)
        .background(Theme.card.ignoresSafeArea(edges: .top))
    }
}

// MARK: - Bottom navigation

struct BottomBar: View {
    @Binding var selection: AppPage

    var body: some View {
        HStack(spacing: 0) {
            ForEach(AppPage.allCases) { item in
                Button {
                    selection = item
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: item.symbol)
                            .font(.system(size: 18))
                        Text(item.navLabel)
                            .font(.system(size: 10))
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                    }
                    .foregroundColor(tint(for: item))
                    .frame(maxWidth: .infinity, minHeight: 70)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .background(
            Theme.card
                .shadow(color: Color.black.opacity(0.08), radius: 8, x: 0, y: -2)
                .ignoresSafeArea(edges: .bottom)
        )
    }

    private func tint(for item: AppPage) -> Color {
        if item == .followups { return Theme.red }      // Alerts is always red
        return item == selection ? Theme.blue : Theme.textSecondary
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(AuthStore())
            .environmentObject(Store())
    }
}
