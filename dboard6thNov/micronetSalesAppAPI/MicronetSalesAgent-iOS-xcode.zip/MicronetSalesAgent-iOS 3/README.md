# Micronet Sales Agent – iOS (SwiftUI)

## Run it
1. Unzip, then double-click **MicronetSalesAgent.xcodeproj** (the file inside this folder – not the folder itself).
2. Pick an iPhone simulator at the top of Xcode and press **Cmd+R**.
   (To run on a real iPhone: target > Signing & Capabilities > choose your Team.)
3. Sign in with `agent` / `micronet123`.

Requires Xcode 14+ and iOS 15+. No third-party dependencies.

## What's included

- **Login** (`LoginView.swift`, `AuthStore` in `Models.swift`): validation, show/hide password,
  loading and error states. Demo login: `agent` / `micronet123` (shown in Debug builds only).
  Replace `AuthStore.signIn` with your backend call and store the token in the Keychain.
- **Sign out**: the ... menu in the header.
- **Interactive pages** (`Pages.swift`, replacing `PlaceholderPageView`): Visits, Customers, Sales,
  Invoices, Alerts and Products, each with search, filter chips and an add form where it makes sense.
  Actions cross-update (e.g. paying an invoice clears its alert; a sale reduces product stock).
- **Dashboard** now reads live totals from the same data, and its buttons navigate to the pages.
- **Data** lives in memory in `Store` (`Models.swift`) and resets on relaunch. Swap it for your API or
  Core Data / SwiftData. Call buttons use `tel://` and only work on a real device.
